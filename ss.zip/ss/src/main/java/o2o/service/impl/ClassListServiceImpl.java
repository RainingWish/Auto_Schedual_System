package o2o.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import o2o.dao.ClassListDao;
import o2o.entity.ClassList;
import o2o.service.ClassListService;

@Service
public class ClassListServiceImpl implements ClassListService{

	@Autowired
	private ClassListDao classListDao;
	
	
	@Override
	public List<ClassList> getClassList(){
		
		return classListDao.queryClassList();
		
	}
	
	@Override
	public List<ClassList> getSelectClassList(String className) {
		return classListDao.selectClassList(className);
	}
	
	@Override
	public List<ClassList> getCourseList(){
		
		return classListDao.queryCourseList();
		
	}
	
}
