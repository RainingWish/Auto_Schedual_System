package o2o.service;

import java.util.List;

import o2o.entity.ClassList;

public interface ClassListService {

	List<ClassList> getClassList();

	List<ClassList> getSelectClassList(String className);
	
	List<ClassList> getCourseList();
}
