package o2o.web.ss;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/ss")
public class SsFrontendController {

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	private String index() {
		return "ss/index";
	}
	
	@RequestMapping(value = "/main", method = RequestMethod.GET)
	private String showShopList() {
		return "ss/main";
	}
	
}
